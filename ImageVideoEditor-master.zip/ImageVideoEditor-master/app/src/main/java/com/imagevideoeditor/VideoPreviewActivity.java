package com.imagevideoeditor;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.databinding.DataBindingUtil;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.CursorLoader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Toast;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.imagevideoeditor.Utils.DimensionData;
import com.imagevideoeditor.databinding.ActivityVideoPreviewBinding;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION;
import static com.imagevideoeditor.Utils.Utils.getScaledDimension;

public class VideoPreviewActivity extends AppCompatActivity {

    private ActivityVideoPreviewBinding binding;
    private MediaPlayer m1;
    private String videoPath = "";
    private int originalDisplayWidth;
    private int originalDisplayHeight;
    private int newCanvasWidth, newCanvasHeight;
    private int DRAW_CANVASW = 0;
    private int DRAW_CANVASH = 0;
    static final boolean n = true;
    ProgressDialog m=null;
    FFmpeg fFmpeg;
    String l;
    String path2;
    private MediaPlayer.OnCompletionListener onCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mediaPlayer) {
            mediaPlayer.start();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_video_preview);
        videoPath = getIntent().getStringExtra("DATA");
        fFmpeg=FFmpeg.getInstance(this);

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(videoPath);
        String metaRotation = retriever.extractMetadata(METADATA_KEY_VIDEO_ROTATION);
        int rotation = metaRotation == null ? 0 : Integer.parseInt(metaRotation);
        if (rotation == 90 || rotation == 270) {
            DRAW_CANVASH = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            DRAW_CANVASW = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
        } else {
            DRAW_CANVASW = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            DRAW_CANVASH = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
        }
        setCanvasAspectRatio();

        Log.d("new size>>","W = "+newCanvasWidth + " H = "+newCanvasHeight);
     /*   binding.videoPreview.getLayoutParams().width = newCanvasWidth;
        binding.videoPreview.getLayoutParams().height = newCanvasHeight;
*/
        binding.videoPreview.getLayoutParams().width = 400;
        binding.videoPreview.getLayoutParams().height = 513;

        binding.audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent videoIntent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(Intent.createChooser(videoIntent, "Select Audio"), 1);

            }
        });


        binding.save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                f();

            }
        });

        binding.videoPreview.setVideoPath(videoPath);
        binding.videoPreview.start();


     /*   binding.videoPreview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
//                activityHomeBinding.videoSurface.getLayoutParams().height=640;
//                activityHomeBinding.videoSurface.getLayoutParams().width=720;
                Surface surface = new Surface(surfaceTexture);

                try {
                    m1 = new MediaPlayer();
//                    mediaPlayer.setDataSource("http://daily3gp.com/vids/747.3gp");
                    Log.d("VideoPath>>", videoPath);
                    m1.setDataSource(videoPath);
                    m1.setSurface(surface);
                    m1.prepare();
                    m1.setOnCompletionListener(onCompletionListener);
                    m1.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    m1.start();
                } catch (IllegalArgumentException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (SecurityException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IllegalStateException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                return false;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

            }
        });*/





    }

    private void setCanvasAspectRatio() {

        originalDisplayHeight = getDisplayHeight();
        originalDisplayWidth = getDisplayWidth();

        DimensionData displayDiamenion =
                getScaledDimension(new DimensionData((int) DRAW_CANVASW, (int) DRAW_CANVASH),
                        new DimensionData(originalDisplayWidth, originalDisplayHeight));
        newCanvasWidth = displayDiamenion.width;
        newCanvasHeight = displayDiamenion.height;

    }

    private int getDisplayWidth() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.widthPixels;
    }

    private int getDisplayHeight() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.heightPixels;
    }







    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && null != data) {
            if (requestCode == 1) {

                Uri uri = data.getData();
                try {
                    String uriString = uri.toString();
                    File myFile = new File(uriString);
                    //    String path = myFile.getAbsolutePath();
                    String displayName = null;
                    path2 = getAudioPath(uri);

                        binding.text.setText(path2);


                    binding.videoPreview.setVideoURI(Uri.parse(videoPath));
                    binding.videoPreview.requestFocus();
                    binding.videoPreview.start();

                    // video1

                    binding.videoPreview.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mediaPlayer) {

                            binding.videoPreview.start();
                            stopPlaying();
                            m1 = MediaPlayer.create(VideoPreviewActivity.this,Uri.parse(path2));
                            m1.start();
                        }
                    });

                    binding.videoPreview.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mediaPlayer) {

                            stopPlaying();

                        }
                    });




                    Log.e("aaa",path2);

                   /* long fileSizeInBytes = f.length();
                    long fileSizeInKB = fileSizeInBytes / 1024;
                    long fileSizeInMB = fileSizeInKB / 1024;*/

                } catch (Exception e) {
                    //handle exception
                }
                //   String path1 = uri.getPath();

            }
        }

    }










    private String getAudioPath(Uri uri) {
        String[] data = {MediaStore.Audio.Media.DATA};
        CursorLoader loader = new CursorLoader(getApplicationContext(), uri, data, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Audio.AudioColumns.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }







    private void f() {
        String format = new SimpleDateFormat("_HHmmss", Locale.US).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().getAbsoluteFile());
        sb.append("/");
        sb.append(getResources().getString(R.string.MainFolderName));
        sb.append("/");
        sb.append(getResources().getString(R.string.AudioVideoMixer));
        this.l = sb.toString();
        File file = new File(this.l);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStorageDirectory().getAbsoluteFile());
        sb2.append("/");
        sb2.append(getResources().getString(R.string.MainFolderName));
        sb2.append("/");
        sb2.append(getResources().getString(R.string.AudioVideoMixer));
        sb2.append("/audiovideomixer");
        sb2.append(format);
        sb2.append(".mkv");
        this.l = sb2.toString();
        int duration = binding.videoPreview.getDuration() / 1000;
        a(new String[]{"-y",  "-i",videoPath, "-i",path2, "-map", "0:0", "-map", "1:0", "-acodec", "copy", "-vcodec", "copy", "-preset", "ultrafast", "-ss", "0", "-t", String.valueOf(duration), this.l}, this.l);
        //  a(new String[]{"-y", "-ss", String.valueOf(this.v.getStart() / 1000), "-t", String.valueOf(duration), "-i", this.v.getFilename(), "-ss", String.valueOf((a != null ? a.getLeftProgress() : 0) / 1000), "-i", AddAudio.audioPath, "-map", "0:0", "-map", "1:0", "-acodec", "copy", "-vcodec", "copy", "-preset", "ultrafast", "-ss", "0", "-t", String.valueOf(duration), this.l}, this.l);
    }

    private void a(String[] strArr, final String str) {
        try {
            this.m = new ProgressDialog(VideoPreviewActivity.this);
            this.m.setMessage("Adding Audio...");
            this.m.setCancelable(false);
            this.m.setIndeterminate(n);
            this.m.show();
            this.fFmpeg.execute(strArr, new ExecuteBinaryResponseHandler() {
                @Override
                public void onStart() {
                }

                @Override
                public void onFailure(String str) {
                    Log.d("ffmpegfailure", str);
                    new File(str).delete();
                    VideoPreviewActivity.this.deleteFromGallery(str);
                    Toast.makeText(VideoPreviewActivity.this, "Error Creating Video", 0).show();
                }


                @Override
                public void onSuccess(String str) {
                    if (VideoPreviewActivity.this.m != null && VideoPreviewActivity.this.m.isShowing()) {
                        VideoPreviewActivity.this.m.dismiss();
                    }
                    MediaScannerConnection.scanFile(VideoPreviewActivity.this, new String[]{VideoPreviewActivity.this.l}, new String[]{"mkv"}, null);
                   /* stopPlaying();
                    Intent intent=new Intent(getApplicationContext(),FinalVideoView.class);
                    intent.putExtra("path",l);
                    startActivity(intent);
                    finish();*/

                   Toast.makeText(getApplicationContext(),"VideoPath:"+l,Toast.LENGTH_LONG).show();

                }

                @Override public void onProgress(String str) {
                    Log.d("ffmpegResponse", str);
                }

                @Override public void onFinish() {
                    VideoPreviewActivity.this.m.dismiss();
                    VideoPreviewActivity.this.refreshGallery(str);
                }
            });
            getWindow().clearFlags(16);
        } catch (FFmpegCommandAlreadyRunningException unused) {
        }



    }


    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }
    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }








    private void stopPlaying() {
        if (m1 != null) {
            m1.stop();
            m1.release();
            m1 = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (m1 != null) {
            m1.stop();
            m1.release();
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();

    stopPlaying();
    }
}
