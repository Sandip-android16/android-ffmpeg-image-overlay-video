package com.imagevideoeditor.Utils;

/**
 * Created by jaypal on 4/1/18.
 */
public interface Constant {

    String FORMAT1 = "HH:mm";
    String FORMAT2 = "hh:mm a";
    String FORMAT3 = "dd/MM/yyyy";
    String FORMAT4 = "yyyy-MM-dd";
    String FORMAT5 = "dd MMM, yyyy";

}