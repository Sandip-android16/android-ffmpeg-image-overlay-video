package com.imagevideoeditor;


public enum ToolType {
    BRUSH,
    TEXT,
    STICKER
}
