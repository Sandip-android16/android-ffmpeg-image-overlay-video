# ImageVideoEditor
This project is Simple Demo for Image and Video Editing with swipeing overlay stickers(like snapchat),Add stickers,Add text,Drawing funcationlity etc.

Also this Demo uses photoeditor lib,ffmpeg and multipicker for image and video picker.

![Alt text](/screenshot/Screenshot_1588476592.png "Picker")

With Available tools:

![Alt text](/screenshot/Screenshot_1588476592.png "Tools")

Swiping stickers:

![Alt text](/screenshot/Screenshot_1588477254.png "Swipe stickers")

Stickers,Drawing and text:

![Alt text](/screenshot/Screenshot_1588476722.png "stickers,text,drawing")
